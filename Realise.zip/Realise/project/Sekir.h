#ifndef SEKIR_H_INCLUDED
#define SEKIR_H_INCLUDED

#include <iostream>
#include <fstream>
#include <cstring>
#include <graphics.h>
#include <windows.h>
#include <mmsystem.h>
#include <cstdio>
#include <time.h>
using namespace std;

extern char phone[];
extern char SekirSkin[];
extern char name[];
extern char skina[];
extern char BackGround[];

struct recorder{
    char name[20];
    int points;
};

struct point
{
  int x;
  int y;
};

int Pause();
void SaveinFile(int pointers);
int loses(void *BG,void *lose,int x,char P[],char skinok[]);
void GamePlay();
void Fading();
int Menu();
void Settings();
void VvodName();
void Name();
void Skin();
void Records();
void BackGroundSetting();
int Exit();
void LoadAnimation();
void interfaces();
void LoadData();

#endif // SEKIR_H_INCLUDED
