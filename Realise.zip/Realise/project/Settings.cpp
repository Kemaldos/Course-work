#include "Sekir.h"

void Settings(){
    readimagefile("img/hover/set0.jpg",0,0,1550,800);
    int xm,ym,NumberButton;
    clearmouseclick(WM_LBUTTONDOWN);
    while(1){
        xm = mousex();
        ym = mousey();
        if(xm>50 && xm<185 && ym>35 && ym<97)
            readimagefile("img/hover/set5.jpg",0,0,1550,800);
        else if(xm>260 && xm<675 && ym>220 && ym<335)
            readimagefile("img/hover/set1.jpg",0,0,1550,800);
        else if(xm>875 && xm<1285 && ym>220 && ym<335)
            readimagefile("img/hover/set2.jpg",0,0,1550,800);
        else if(xm>260 && xm<675 && ym>495 && ym<615)
            readimagefile("img/hover/set3.jpg",0,0,1550,800);
        else if(xm>875 && xm<1285 && ym>495 && ym<615)
            readimagefile("img/hover/set4.jpg",0,0,1550,800);
        else readimagefile("img/hover/set0.jpg",0,0,1550,800);

        if(ismouseclick(WM_LBUTTONDOWN)){
            if(xm>50 && xm<185 && ym>35 && ym<97){
                NumberButton = 5; break;
            }else if(xm>260 && xm<675 && ym>220 && ym<335){
                NumberButton = 1; break;
            }else if(xm>875 && xm<1285 && ym>220 && ym<335){
                NumberButton = 2; break;
            }else if(xm>260 && xm<675 && ym>495 && ym<615){
                NumberButton = 3; break;
            }else if(xm>875 && xm<1285 && ym>495 && ym<615){
                NumberButton = 4; break;
            }else clearmouseclick(WM_LBUTTONDOWN);
        }
    }
    if(NumberButton == 1){
        Name();
    }else if(NumberButton == 2){
        Skin();
    }else if(NumberButton == 3){
        Records();
    }else if(NumberButton == 4){
        BackGroundSetting();
    }else if(NumberButton == 5){
        PlaySound(TEXT("sound/menusong.wav"),NULL,SND_ASYNC);
        interfaces();
    }
}

void VvodName()
{
    readimagefile("img/name/name1.jpg",0,0,1550,800);
    int i=-1,PosX,height;
    height = textwidth(name)/2;
    PosX = 775 - height;
    outtextxy(PosX,65,name);
    char namestr[30],ch;
    while(ch != 13){
        ch = getch();
        if(ch != 8){
            namestr[i] += ch;
            namestr[i + 1] = '\0';
            i++;
        }else if(ch == 8){
            if(i>0){
                setfillstyle(1,0);
                bar(385,345,1170,455);
                namestr[strlen(namestr) - 1] = '\0';
                i--;
            }
        }
        height = textwidth(namestr)/2;
        PosX = 775 - height;
        outtextxy(PosX,375,namestr);
        if(i>15) break;
    }
    if(i==0) {namestr[0]='A';namestr[1] ='\0';}
    setfillstyle(1,0);
    bar(385,345,1170,455);
    ofstream fout("name/name.txt");
    fout << namestr;
    fout.close();
    strcpy(name,namestr);
    readimagefile("img/name/name0.jpg",0,0,1550,800);
}

void Name()
{
    readimagefile("img/name/name0.jpg",0,0,1550,800);
    int xm,ym,NumberButton,PosX,height;
    clearmouseclick(WM_LBUTTONDOWN);
    settextstyle(10,0,5);
    setbkcolor(0);
    ifstream fin("name/name.txt");
    fin >> name;
    height = textwidth(name)/2;
    PosX = 775 - height;
    while(1){
        NumberButton = 0;
        xm = mousex();
        ym = mousey();
        if(xm>366 && xm<1183 && ym>330 && ym<468)
            readimagefile("img/name/name1.jpg",0,0,1550,800);
        else if(xm>48 && xm<185 && ym>34 && ym<96)
            readimagefile("img/name/name2.jpg",0,0,1550,800);
        else readimagefile("img/name/name0.jpg",0,0,1550,800);

        if(ismouseclick(WM_LBUTTONDOWN)){
            if(xm>366 && xm<1183 && ym>330 && ym<468){
                NumberButton = 1;
            }else if(xm>48 && xm<185 && ym>34 && ym<96){
                NumberButton = 2;
            }else clearmouseclick(WM_LBUTTONDOWN);
        }
        if(NumberButton == 1){
            VvodName();
            clearmouseclick(WM_LBUTTONDOWN);
        }else if(NumberButton == 2){
            break;
        }
        height = textwidth(name)/2;
        PosX = 775 - height;
        outtextxy(PosX,65,name);
    }
    fin.close();
    Settings();
}

void Skin()
{
    readimagefile(skina,0,0,1550,800);
    int xm,ym,NumberButton;
    while(1){
        clearmouseclick(WM_LBUTTONDOWN);
        xm = mousex();
        ym = mousey();
        if(xm>90 && xm<510 && ym>303 && ym<530)
            readimagefile("img/skins/skiner1.jpg",0,0,1550,800);
        else if(xm>570 && xm<990 && ym>303 && ym<530)
            readimagefile("img/skins/skiner2.jpg",0,0,1550,800);
        else if(xm>1055 && xm<1480 && ym>330 && ym<530)
            readimagefile("img/skins/skiner3.jpg",0,0,1550,800);
        else if(xm>48 && xm<185 && ym>34 && ym<96)
            readimagefile("img/skins/skiner4.gif",0,0,1550,800);
        else readimagefile(skina,0,0,1550,800);

        if(ismouseclick(WM_LBUTTONDOWN)){
            if(xm>48 && xm<185 && ym>34 && ym<96){
                NumberButton = 4;
            }else if(xm>90 && xm<510 && ym>303 && ym<530){
                NumberButton = 1;
            }else if(xm>570 && xm<990 && ym>303 && ym<530){
                NumberButton = 2;
            }else if(xm>1055 && xm<1480 && ym>303 && ym<530){
                NumberButton = 3;
            }else clearmouseclick(WM_LBUTTONDOWN);
        }
        if(NumberButton == 1){
            skina[16] = *"1";
            SekirSkin[10] = *"1";
        }else if(NumberButton == 2){
            skina[16] = *"2";
            SekirSkin[10] = *"2";
        }else if(NumberButton == 3){
            skina[16] = *"3";
            SekirSkin[10] = *"3";
        }else if(NumberButton == 4){
            break;
        }
    }
    Settings();
}

void Records()
{
    readimagefile("img/record/record0.jpg",0,0,1550,800);
    int xm,ym,NumberButton=0, heightN, heightP, PosXN, PosXP;
    clearmouseclick(WM_LBUTTONDOWN);
    settextstyle(10,0,5);
    setbkcolor(8);
    struct recorder basa[5];
    ifstream fin("records/basa.txt");
    for(int i=0,y=235;i<5;i++,y+=95){
        fin >> basa[i].name;
        fin >> basa[i].points;
        char PointsStr[30];
        sprintf(PointsStr,"%d",basa[i].points);
        heightN = textwidth(basa[i].name)/2;
        PosXN = 605 - heightN;
        heightP = textwidth(PointsStr)/2;
        PosXP = 1085 - heightP;
        outtextxy(PosXN,y,basa[i].name);
        outtextxy(PosXP,y,PointsStr);
    }
    fin.close();
    while(1){
        xm = mousex();
        ym = mousey();
        if(xm>48 && xm<185 && ym>34 && ym<96)
            readimagefile("img/record/record1.gif",0,0,1550,800);
        else readimagefile("img/record/record0.gif",0,0,1550,800);
        if(ismouseclick(WM_LBUTTONDOWN)){
            if(xm>48 && xm<185 && ym>34 && ym<96){
                NumberButton = 1;
            }else clearmouseclick(WM_LBUTTONDOWN);
        }
        if(NumberButton == 1){
            break;
        }
    }
    Settings();
}

void BackGroundSetting(){
    readimagefile(phone,0,0,1550,800);
    int xm,ym,NumberButton;
    while(1){
        clearmouseclick(WM_LBUTTONDOWN);
        xm = mousex();
        ym = mousey();
        if(xm>90 && xm<510 && ym>303 && ym<530)
            readimagefile("img/bg/bg1.jpg",0,0,1550,800);
        else if(xm>570 && xm<990 && ym>303 && ym<530)
            readimagefile("img/bg/bg2.jpg",0,0,1550,800);
        else if(xm>1055 && xm<1480 && ym>330 && ym<530)
            readimagefile("img/bg/bg3.jpg",0,0,1550,800);
        else if(xm>48 && xm<185 && ym>34 && ym<96)
            readimagefile("img/bg/bg4.gif",0,0,1550,800);
        else readimagefile(phone,0,0,1550,800);

        if(ismouseclick(WM_LBUTTONDOWN)){
            if(xm>48 && xm<185 && ym>34 && ym<96){
                NumberButton = 4;
            }else if(xm>90 && xm<510 && ym>303 && ym<530){
                NumberButton = 1;
            }else if(xm>570 && xm<990 && ym>303 && ym<530){
                NumberButton = 2;
            }else if(xm>1055 && xm<1480 && ym>303 && ym<530){
                NumberButton = 3;
            }else clearmouseclick(WM_LBUTTONDOWN);
        }
        if(NumberButton == 1){
            phone[9] = *"1";
            BackGround[10] = *"1";
        }else if(NumberButton == 2){
            phone[9] = *"2";
            BackGround[10] = *"2";
        }else if(NumberButton == 3){
            phone[9] = *"3";
            BackGround[10] = *"3";
        }else if(NumberButton == 4){
            break;
        }
    }
    Settings();
}

void LoadAnimation()
{
    PlaySound(TEXT("sound/load.wav"),NULL,SND_ASYNC);
    int x = 666;
    delay(200);
    for(int i=19;i>-1;i--){
        char strin[40];
        sprintf(strin,"img/transition/int%d.jpg",i);
        readimagefile(strin,0,0,1550,800);
        delay(30);
    }
    delay(3000);
    for(int i=0;i<20;i++){
        char strin[40];
        sprintf(strin,"img/transition/int%d.jpg",i);
        readimagefile(strin,0,0,1550,800);
        delay(30);
    }
    cleardevice();
    delay(2000);

    readimagefile("img/transition/ico.jpg",0,0,1550,800);
    setfillstyle(1,15);
    for(int i=0;i<60;i++){
        bar(665,425,x,448);
        x = x + 3;
        delay(100);
    }
    delay(2000);

    for(int i=0;i<30,x<888;i++){
        bar(665,425,x,448);
        x = x + 3;
        delay(70);}
    for(int i=0;i<20;i++){
        char strin2[40];
        sprintf(strin2,"img/transition/ico%d.jpg",i);
        readimagefile(strin2,0,0,1550,800);
        delay(50);}

    cleardevice();
    delay(2000);
}
