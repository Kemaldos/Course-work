#include "Sekir.h"

void GamePlay()
{
    readimagefile("img/hover/lose0.jpg",0,0,1000,700);
    void *lose; unsigned size4=4;
    size4 = imagesize(0,0,1000,700);
    lose = malloc(size4);
    getimage(0,0,1000,700,lose);

    readimagefile(BackGround,0,0,1550,800);
    void *BG; unsigned size;
    size = imagesize(0,0,1550,800);
    BG = malloc(size);
    getimage(0,0,1550,800,BG);

    readimagefile("img/Gameplay/plat0.gif",0,0,68,14);
    void *PL0; unsigned size0;
    size0 = imagesize(0,0,68,14);
    PL0 = malloc(size0);
    getimage(0,0,68,14,PL0);

    readimagefile("img/Gameplay/plat1.gif",0,0,68,14);
    void *PL; unsigned size2;
    size2 = imagesize(0,0,68,14);
    PL = malloc(size2);
    getimage(0,0,68,14,PL);

    readimagefile("img/Gameplay/plat2.gif",0,0,68,14);
    void *PL2; unsigned size5;
    size5 = imagesize(0,0,68,14);
    PL2 = malloc(size5);
    getimage(0,0,68,14,PL2);

    readimagefile("img/Gameplay/plat3.gif",0,0,68,68);
    void *PL3; unsigned size6;
    size6 = imagesize(0,0,68,68);
    PL3 = malloc(size6);
    getimage(0,0,68,68,PL3);

    char ch,chx;
    int dvij[20] = {2,-2,2,-2,2,-2,2,-2,2,-2,2,-2,2,-2,2,-2,2,-2,2,-2}

    ,dvij2[5]={2,-2,2,-2,2};
    float sdvig[20],sdvig2[5]={0};
    for(int i=0;i<20;i++){
        sdvig[i] = 0;
    }
    int level1=1000, level2=2000, level3=3000,hard=1;
    int n = 20, m=5, pointers = 0,levelok=0, k, k2, checkstone = 0, height2, POX, l, paus,
    prnapr = 2, dviga, pruj, kum, checkpr=0, checkkum=0, kumis = 3000,lost=0;
    float v = 0, v2, g = -15, y = 400, x = 700, h = 400, p, r,xs,ys=1,vd=0,asd[20];

    struct point plat[n];
    struct point lol[n];
    struct point stena;
    struct point prujka;
    struct point kumka;
    for(int i=0;i<n;i++){
        plat[i].x = rand() % 1550;
        plat[i].y = rand() % 800;
    }
    for(int i=0;i<5;i++){
        lol[i].x = rand()%(1550-68);
        lol[i].y = rand()%800;
    }
    kumka.x = 0;
    kumka.y = 1000;
    plat[0].x = 700;
    plat[0].y = 750;
    r = -20;
    setbkcolor(0);
    settextstyle(10,0,4);
    PlaySound(0,0,0);
    PlaySound(TEXT("sound/game.wav"),NULL,SND_ASYNC);

    while(1){

        if(checkpr==0){
            pruj = rand()%200;
            if(pruj == 1) {
                checkpr = 1;
                prujka.x = rand()%(1550-68);
                prujka.y = -14;
            }
        }
        if(checkkum==0){
            kum = rand()%40000;
            if(kum == 1) {
                checkkum = 1;
                kumka.x = rand()%1550;
                kumka.y = -68;
            }
        }

        if(ys<=-200) checkstone = 0;

        if(x < -50) x = 1500;
        if(x > 1500) x = -50;
        if(GetAsyncKeyState(VK_RIGHT)) {x = x + 7; if(checkstone == 0 ) {SekirSkin[15] = *"r"; p = 1;}}
        if(GetAsyncKeyState(VK_LEFT)) {x = x - 7; if(checkstone == 0 ) {SekirSkin[15] = *"l"; p = 0;}}

        if(hard==3 || hard==6){         // Swim
            if(prujka.x <= 0 || prujka.x + 68 > 1550)
                prnapr = -prnapr;
            prujka.x += prnapr;

            for(int i=0;i<20;i++){

                if(plat[i].x <= 0 || plat[i].x + 68 > 1550)
                    dvij[i] = -dvij[i];
                plat[i].x += dvij[i];


            }
            for(int i=0;i<m;i++){
                if(lol[i].x <= 0 || lol[i].x + 68 >= 1550)
                    dvij2[i] = -dvij2[i];
                lol[i].x += dvij2[i];
            }
        }

        if((hard==4) && v<0 && v >-21){    // Skachut
            for(int i=0;i<20;i++){
                sdvig[i] += asd[i];
                plat[i].x += sdvig[i];
            }
            for(int i=0;i<m;i++){
                sdvig2[i] += asd[i];
                lol[i].x += sdvig2[i];
            }
            prujka.x += sdvig[0];
        }

        if(kbhit()){
            ch = getch();

            if(ch == 27){
                paus = Pause();
                if(paus == 2){
                    break;
                }
            }

            if(ch==72){
                if(checkstone == 0){
                    SekirSkin[15] = *"u"; checkstone = 1; xs = x, ys = y;
                }
            }
        }
        if(p==1 && checkstone == 0) SekirSkin[15] = *"r";
        else if(p==0 && checkstone == 0) SekirSkin[15] = *"l";

        v = v + 0.6;
        y = y + v;

        if(y < 300){
            if(checkpr == 1)
            prujka.y -= v;

            if(checkkum == 1)
            kumka.y -= v;

            for(int i=0;i<n;i++){
                y = 300;
                plat[i].y = plat[i].y - v;
                lol[i].y -= v;

                pointers -= (v/15);
                levelok -= (v/15);
                k = rand()%100;
                if(k==1){
                    int w = rand()%10;
                    pointers += w;
                    levelok += w;
                }

                if(plat[i].y > 800){
                    plat[i].y = 0;
                    plat[i].x = rand()%(1550-68);
                }

                if(lol[i].y > 800){
                    lol[i].y = 0;
                    lol[i].x = rand()%(1550-68);
                }

            }
        }
        if(prujka.y > 800) {checkpr = 0; prujka.y = 1000;}
        if(kumka.y > 800) checkkum = 0;

        if((x+72 >= prujka.x) && (x+28 < prujka.x+68) && (y+100 > prujka.y)
           && (y+100<prujka.y+36) && (v>0)) v = -35;

        for(int i=0;i<n;i++){
            if((x+72 >= plat[i].x) && (x+28 < plat[i].x + 68)
               && (y+100 > plat[i].y) && (y+100 < plat[i].y + 36) && (v > 0))
               {
                        v = r;
                        for(int i=0;i<n;i++){
                            int w = rand()%2;
                            if(w%2==0) asd[i] = 0.15;
                            else asd[i] = -0.15;
                            sdvig[i] = 0;
                        }
                        for(int i=0;i<m;i++) sdvig2[i]=0;
                        if(hard==2 || hard==6) plat[i].y = 801;

                }
        }

        if(checkstone == 1){
            readimagefile("img/Gameplay/stone.gif",xs+40,ys-10,xs+60,ys+10);
            ys = ys - 40;
            for(int i=0;i<n;i++){
                if((xs+40+20>plat[i].x) && (xs+40<plat[i].x+68) &&
                (ys-10>plat[i].y) && (ys-10<plat[i].y+44)) {
                    plat[i].y=801;ys=-400;break;}
            }
        }

        swapbuffers();
        putimage(0,0,BG,COPY_PUT);
        for(int i=0;i<5;i++) putimage(lol[i].x,lol[i].y,PL0,COPY_PUT);
        for(int i=0;i<n;i++){
            putimage(plat[i].x, plat[i].y,PL,COPY_PUT);
        }
        putimage(prujka.x,prujka.y,PL2,COPY_PUT);
        putimage(kumka.x,kumka.y,PL3,COPY_PUT);

        readimagefile(SekirSkin, x, y, x+100, y+100);

        char P[40];
        sprintf(P,"%d",pointers);
        height2 = textwidth(P)/2;
        POX = 125 - height2;
        outtextxy(POX,30,P);
        delay(1);

        if(levelok>3000){
            levelok = 0;
            if(hard != 6) hard++;
            else hard = 1;
        }

        if(y + 100 >= 820)              // if player losed
        {
            PlaySound(TEXT("sound/ended.wav"),NULL,SND_ASYNC);
            while(1){
                v = -30;
                v2 = -10;
                y = y + v2;

                for(int i=0;i<n;i++){
                    plat[i].y = plat[i].y + v;
                }

                swapbuffers();
                putimage(0,0,BG,COPY_PUT);
                for(int i=0;i<n;i++){
                    putimage(plat[i].x, plat[i].y,PL,COPY_PUT);
                }
                readimagefile(SekirSkin, x, y, x+100, y+100);
                outtextxy(POX,30,P);
                setvisualpage(getactivepage());
                if(y<-700){
                    SaveinFile(pointers);
                    l = loses(BG,lose,x,P,SekirSkin);
                    break;
                }
            }
            break;
        }
    }
    free(lose);
    free(BG);
    free(PL0);
    free(PL);
    free(PL2);
    free(PL3);
    if(paus == 2){
        PlaySound(TEXT("sound/menusong.wav"),NULL,SND_ASYNC);
        interfaces();
    }
    if(l == 1){
        GamePlay();
    }else if(l == 2){
        PlaySound(TEXT("sound/menusong.wav"),NULL,SND_ASYNC);
        interfaces();
    }
}

int Pause()
{
    setvisualpage(getactivepage());
    int NumberButton=0,xm,ym;
    clearmouseclick(WM_LBUTTONDOWN);
    while(1){
        xm = mousex();
        ym = mousey();
        if(xm>588 && xm<963 && ym>338 && ym<420)
            readimagefile("img/hover/pause1.gif",0,0,1550,800);
        else if(xm>588 && xm<963 && ym>465 && ym<540)
            readimagefile("img/hover/pause2.gif",0,0,1550,800);
        else readimagefile("img/hover/pause0.gif",0,0,1550,800);

        if(ismouseclick(WM_LBUTTONDOWN)){
            if(xm>588 && xm<963 && ym>338 && ym<420){
                NumberButton = 1; break;
            }else if(xm>588 && xm<963 && ym>465 && ym<540){
                NumberButton = 2; break;
            }else clearmouseclick(WM_LBUTTONDOWN);
        }
    }
    return NumberButton;
}

int loses(void *BG,void *lose,int x,char P[],char skinok[])
{
    settextstyle(10,0,6);
    int PosX,height,xm,ym,NumberButton=0;
    height = textwidth(P)/2;
    PosX = 978 - height;
    for(int o=800;o>=50;o-=10){
        swapbuffers();
        putimage(0,0,BG,COPY_PUT);
        putimage(275,o,lose,COPY_PUT);
        outtextxy(PosX,o+275,P);
    }
    setvisualpage(getactivepage());
    for(int o=-100;o<900;o+=40){
        swapbuffers();
        putimage(0,0,BG,COPY_PUT);
        putimage(275,50,lose,COPY_PUT);
        outtextxy(PosX,325,P);
        readimagefile(skinok, x, o, x+100, o+100);
    }
    setvisualpage(getactivepage());
    while(1){
        clearmouseclick(WM_LBUTTONDOWN);
        xm = mousex();
        ym = mousey();
        if(xm>630 && xm<918 && ym>470 && ym<551)
            readimagefile("img/hover/lose1.gif",0,0,1550,800);
        else if(xm>627 && xm<915 && ym>600 && ym<682)
            readimagefile("img/hover/lose2.gif",0,0,1550,800);
        else readimagefile("img/hover/lose0.gif",0,0,1550,800);

        if(ismouseclick(WM_LBUTTONDOWN)){
            if(xm>630 && xm<918 && ym>470 && ym<551){
                NumberButton = 1;
            }else if(xm>627 && xm<915 && ym>600 && ym<682){
                NumberButton = 2;
            }else clearmouseclick(WM_LBUTTONDOWN);
        }

        if(NumberButton == 1){
            return 1;
        }else if(NumberButton == 2){
            return 2;
        }
    }
}

void SaveinFile(int pointers)
{
    struct recorder basa[6];
    struct recorder tmp;
    ifstream fin("records/basa.txt");
    for(int i=0;i<5;i++){
        fin >> basa[i].name;
        fin >> basa[i].points;
    }
    fin.close();
    strcpy(basa[5].name,name);
    basa[5].points = pointers;
    for(int i=0;i<7;i++){
        for(int j=i+1;j<6;j++){
            if(basa[j].points > basa[i].points){
                tmp = basa[j];
                basa[j] = basa[i];
                basa[i] = tmp;
            }
        }
    }
    ofstream fout;
    fout.open("records/basa.txt");
    for(int i=0;i<5;i++){
        fout << basa[i].name << " ";
        fout << basa[i].points << endl;
    }
    fout.close();
}
