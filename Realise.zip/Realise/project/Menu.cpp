#include "Sekir.h"

char phone[30] = "img/bg/bg1.jpg";
char SekirSkin[30] = "img/Sekir/1skinr.gif";
char name[30];
char skina[30] = "img/skins/skiner1.jpg";
char BackGround[30] = "img/BGR/bg1.jpg";

void interfaces()
{
    readimagefile("img/menu0.jpg",0,0,1550,800);
    int NumberButton = Menu();
    if(NumberButton == 1){
        Fading();
        PlaySound(0,0,0);
        GamePlay();
    }
    else if(NumberButton == 2){
        PlaySound(0,0,0);
        PlaySound(TEXT("sound/zen.wav"),NULL,SND_ASYNC);
        Settings();
    }
    else if(NumberButton == 3){
        int a = Exit();
    }
}

int Menu(){
    char ch=0;
    int xm,ym,NumberButton;
    clearmouseclick(WM_LBUTTONDOWN);
    while(1){
        xm = mousex();
        ym = mousey();
        if(xm>1450 && xm<1525 && ym>650 && ym<760)
            readimagefile("img/hover/menuauthor.jpg",0,0,1550,800);
        else if(xm>550 && xm<995 && ym>195 && ym<320)
            readimagefile("img/hover/menu1.jpg",0,0,1550,800);
        else if(xm>550 && xm<995 && ym>385 && ym<515)
            readimagefile("img/hover/menu2.jpg",0,0,1550,800);
        else if(xm>550 && xm<995 && ym>575 && ym<705)
            readimagefile("img/hover/menu3.jpg",0,0,1550,800);
        else readimagefile("img/hover/menu0.jpg",0,0,1550,800);
        if(ismouseclick(WM_LBUTTONDOWN)){
            if(xm>550 && xm<995 && ym>195 && ym<320){
                NumberButton = 1; break;
            }else if(xm>550 && xm<995 && ym>385 && ym<515){
                NumberButton = 2; break;
            }else if(xm>550 && xm<995 && ym>575 && ym<705){
                NumberButton = 3; break;
            }else clearmouseclick(WM_LBUTTONDOWN);}}

    return NumberButton;
}

int Exit()
{
    readimagefile("img/hover/exit0.jpg",0,0,1550,800);
    int xm,ym,NumberButton=0;
    clearmouseclick(WM_LBUTTONDOWN);
    while(1){
        NumberButton=0;
        xm = mousex();
        ym = mousey();
        if(xm>479 && xm<725 && ym>479 && ym<550)
            readimagefile("img/hover/exit1.jpg",0,0,1550,800);
        else if(xm>833 && xm<1080 && ym>479 && ym<550)
            readimagefile("img/hover/exit2.jpg",0,0,1550,800);
        else readimagefile("img/hover/exit0.jpg",0,0,1550,800);

        if(ismouseclick(WM_LBUTTONDOWN)){
            if(xm>479 && xm<725 && ym>479 && ym<550){
                NumberButton = 1; break;
            }else if(xm>833 && xm<1080 && ym>479 && ym<550){
                NumberButton = 2; break;
            }else clearmouseclick(WM_LBUTTONDOWN);
        }
    }
        if(NumberButton == 1){
        }
        else if(NumberButton == 2){
            interfaces();
        }

    return 0;
}

void LoadData()
{
    ifstream fin("name/name.txt");
    fin >> name;
    fin.close();
}

void Fading()
{
    readimagefile("img/gamego/go0.jpg",0,0,1550,800);
    delay(1000);
    for(int i=0;i<=20;i++){
        char strin[40];
        sprintf(strin,"img/gamego/go%d.jpg",i);
        readimagefile(strin,0,0,1550,800);
        delay(50);
    }
    delay(3000);
}
