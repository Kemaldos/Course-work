#include "Sekir.h"

int main(){
    srand(time(0));
    initwindow(1550,800,"Sekir Jump",10,10);

    LoadData();
    LoadAnimation();

    interfaces();

    closegraph();
    return 0;
}
